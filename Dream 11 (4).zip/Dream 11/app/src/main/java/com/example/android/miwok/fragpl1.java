package example.javatpoint.com.fragmentexample;  
import android.os.Bundle;  
import android.support.v4.app.Fragment;  
import android.view.LayoutInflater;  
import android.view.View;  
import android.view.ViewGroup;  
  
public class fragpl1
 extends Fragment {

    ArrayList<Werd1>
frag1=new ArrayList<Werd1>();
 
 


 
  
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
    }  
  
    @Override  
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  
                             Bundle savedInstanceState) {  
        // Inflate the layout for this fragment  
        return inflater.inflate(R.layout.fragment_fragpl4, container, false);
       frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));
frag1.add(new frag1(R.drawable.player1,"G Akkan","Sel By 75%",0,8.7,R.drawable.bt1));


      ArrayAdapter adapter1 = new ArrayAdapter<Werd1>(this, 
         R.layout.list2, frag1);
      
      ListView listView = (ListView) findViewById(R.id.lister);
      listView.setAdapter(adapter1);



  
    }  
 