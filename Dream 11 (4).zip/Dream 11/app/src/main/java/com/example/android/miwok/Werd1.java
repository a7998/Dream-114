package com.example.android.miwok;


public class Word {

private int mImageResourceId;

private String vs;
private int mImageresourceId;
private String time;
private String unit;



public int getImageResourceid() {

  return mImageResourceId;
}

public String returnvs()
{
  return vs;
}

public String returnvs(){
 
return mImageresourceId;

}
public String getTime() {

 return time;

}
public String getunit() {

 return unit;

}


}

}