package com.example.ListDisplay;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class firstActivity extends AppCompatActivity
{
  ArrayList<Word> first=new ArrayList<Word>();

    first.add(new first(R.drawable.img1,"vs",R.drawable.img2));
    first.add(new first(R.drawable.img2,"vs",R.drawable.img3));
    first.add(new first(R.drawable.img4,"vs",R.drawable.img5));
    first.add(new first(R.drawable.img6,"vs",R.drawable.img7));
    first.add(new first(R.drawable.img8,"vs",R.drawable.img9));
    first.add(new first(R.drawable.img10,"vs",R.drawable.img11));
@Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);
      
      ArrayAdapter adapter = new ArrayAdapter<String>(this, 
         R.layout.list,first);
      
      ListView listView = (ListView) findViewById(R.id.list);
      listView.setAdapter(adapter);

      listView.setOnClickListener(new OnCLickListener(){

public void onItemClick(AdapterView<?> parent, View view, int position,

	                            long id) {

if(position==0) {
   Intent intent = new Intent(this, ListItemActivity61.class);
   startActivity(intent);
}
else if(position==1) {
   Intent intent = new Intent(this, ListItemActivity62.class);
   startActivity(intent);
}
if(position==2) {
   Intent intent = new Intent(this, ListItemActivity63.class);
   startActivity(intent);
}
if(position==3) {
   Intent intent = new Intent(this, ListItemActivity64.class);
   startActivity(intent);
}

      



});



   }
}
    

}
