package com.example.android.miwok;
  
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ListItemActivity32 extends AppCompatActivity {

Button B1;



@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);

B1=(Button)findViewById(R.id.b_1);
B1.setOnClickListener(new OnClickListener(){
 
@Override
private void OnClick(View v)
{
 Intent ig=new Intent(ListItemActivity32.this,launch10.class);
 StartActivity(ig);

}

})


}
}

